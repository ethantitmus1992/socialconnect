﻿using SocialConnectV1.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;

namespace SocialConnectV1.UI.Controllers
{
    public class SupportController : Controller
    {
        // GET: Support
        public ActionResult Index()
        {
            return View();
        }



        public ActionResult Contact()
        {
            return PartialView("Contact");
        }

        [HttpPost]
        public ActionResult Contact(string firstName, string lastName, string email, string message)
        {
            ContactVM vm = new ContactVM();
            vm.FirstName = firstName;
            vm.LastName = lastName;
            vm.Email = email;
            vm.Message = message;

            string body = string.Format("You have received an email from {0} {1}. " +
                "\nEmail: {2}.\nMessage: {3}",
                vm.FirstName,
                vm.LastName,
                vm.Email,
                vm.Message);

            MailMessage m = new MailMessage("etd3v3lopm3nt@gmail.com", "ethantitmus1992@gmail.com", "Contact Info", body);

            using (SmtpClient client = new SmtpClient())
            {
                client.EnableSsl = true;
                client.UseDefaultCredentials = false;
                client.Credentials = new System.Net.NetworkCredential("etd3v3lopm3nt@gmail.com", "5344708Ejt@");
                client.Host = "smtp.gmail.com";
                client.Port = 587;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.Send(m);
            }

            return RedirectToAction("ContactConfirm", vm);
        }

        public ActionResult ContactConfirm(ContactVM vm)
        {
            ViewBag.Message = "Thankyou " + vm.FirstName + ". I will get back with you ASAP!";
            return View(vm);
        }

    }
}