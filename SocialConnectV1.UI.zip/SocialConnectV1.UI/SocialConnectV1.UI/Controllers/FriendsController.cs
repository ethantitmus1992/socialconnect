﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SocialConnectV1.DATA;

namespace SocialConnectV1.UI.Controllers
{
    public class FriendsController : Controller
    {
        private SocialConnectDBEntities db = new SocialConnectDBEntities();

        // GET: Friends
        [Authorize]
        public ActionResult Index()
        {
            User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);

            var friends = db.Friends.Where(x => x.User1Id == u.UserId && x.User2Id != u.UserId || x.User2Id == u.UserId && x.User1Id != u.UserId).Where(x => x.FriendStatusId == 3).ToList();
            return View(friends);
        }

        // GET: Friends/Details/5
        [Authorize(Roles ="Admin")]
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Friend friend = db.Friends.Find(id);
            if (friend == null)
            {
                return HttpNotFound();
            }
            return View(friend);
        }

        // GET: Friends/Create
        [Authorize(Roles = "Admin")]
        public ActionResult Create()
        {
            ViewBag.FriendStatusId = new SelectList(db.FriendStatuses, "FriendStatusId", "Status");
            ViewBag.User1Id = new SelectList(db.Users, "UserId", "FirstName");
            ViewBag.User2Id = new SelectList(db.Users, "UserId", "FirstName");
            return View();
        }

        // POST: Friends/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult Create([Bind(Include = "FriendId,User1Id,User2Id,FriendStatusId")] Friend friend)
        {
            if (ModelState.IsValid)
            {
                db.Friends.Add(friend);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.FriendStatusId = new SelectList(db.FriendStatuses, "FriendStatusId", "Status", friend.FriendStatusId);
            ViewBag.User1Id = new SelectList(db.Users, "UserId", "FirstName", friend.User1Id);
            ViewBag.User2Id = new SelectList(db.Users, "UserId", "FirstName", friend.User2Id);
            return View(friend);
        }

        // GET: Friends/Edit/5
        [Authorize(Roles = "Admin")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Friend friend = db.Friends.Find(id);
            if (friend == null)
            {
                return HttpNotFound();
            }
            ViewBag.FriendStatusId = new SelectList(db.FriendStatuses, "FriendStatusId", "Status", friend.FriendStatusId);
            ViewBag.User1Id = new SelectList(db.Users, "UserId", "FirstName", friend.User1Id);
            ViewBag.User2Id = new SelectList(db.Users, "UserId", "FirstName", friend.User2Id);
            return View(friend);
        }

        // POST: Friends/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult Edit([Bind(Include = "FriendId,User1Id,User2Id,FriendStatusId")] Friend friend)
        {
            if (ModelState.IsValid)
            {
                db.Entry(friend).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.FriendStatusId = new SelectList(db.FriendStatuses, "FriendStatusId", "Status", friend.FriendStatusId);
            ViewBag.User1Id = new SelectList(db.Users, "UserId", "FirstName", friend.User1Id);
            ViewBag.User2Id = new SelectList(db.Users, "UserId", "FirstName", friend.User2Id);
            return View(friend);
        }

        [Authorize]
        public ActionResult Accept(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Friend friend = db.Friends.Find(id);
            if (friend == null)
            {
                return HttpNotFound();
            }
            return PartialView(friend);
        }

        // POST: Friends/Delete/5
        [HttpPost, ActionName("Accept")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult AcceptConfirmed(int id)
        {
            Friend friend = db.Friends.Find(id);
            switch (friend.FriendStatusId)
            {
                case 1:
                    friend.FriendStatusId = 3;
                    break;
                case 2:
                    friend.FriendStatusId = 3;
                    break;
                case 3:
                    friend.FriendStatusId = 3;
                    break;
            }
            db.SaveChanges();
            return RedirectToAction("Index","Users");
        }

        [Authorize]
        public ActionResult Reject(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Friend friend = db.Friends.Find(id);
            if (friend == null)
            {
                return HttpNotFound();
            }
            return PartialView(friend);
        }

        // POST: Friends/Delete/5
        [HttpPost, ActionName("Reject")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult RejectConfirmed(int id)
        {
            Friend friend = db.Friends.Find(id);
            switch (friend.FriendStatusId)
            {
                case 1:
                    friend.FriendStatusId = 2;
                    break;
                case 2:
                    friend.FriendStatusId = 2;
                    break;
                case 3:
                    friend.FriendStatusId = 2;
                    break;
            }
            db.SaveChanges();
            return RedirectToAction("Index", "Users");
        }

        [Authorize]
        public ActionResult UnFriend(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Friend friend = db.Friends.Find(id);
            if (friend == null)
            {
                return HttpNotFound();
            }
            return PartialView(friend);
        }

        // POST: Friends/Delete/5
        [HttpPost, ActionName("UnFriend")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult UnFriendConfirmed(int id)
        {
            Friend friend = db.Friends.Find(id);
            switch (friend.FriendStatusId)
            {
                case 1:
                    friend.FriendStatusId = 2;
                    break;
                case 2:
                    friend.FriendStatusId = 2;
                    break;
                case 3:
                    friend.FriendStatusId = 2;
                    break;
            }
            db.SaveChanges();
            return RedirectToAction("Index", "Users");
        }


        // GET: Friends/Delete/5
        [Authorize(Roles = "Admin")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Friend friend = db.Friends.Find(id);
            if (friend == null)
            {
                return HttpNotFound();
            }
            return View(friend);
        }

        // POST: Friends/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteConfirmed(int id)
        {
            Friend friend = db.Friends.Find(id);
            db.Friends.Remove(friend);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
