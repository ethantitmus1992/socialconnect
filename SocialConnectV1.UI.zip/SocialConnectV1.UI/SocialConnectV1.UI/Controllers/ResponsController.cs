﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SocialConnectV1.DATA;
using System.IO;
using SocialConnectV1.UI.Extensions;

namespace SocialConnectV1.UI.Controllers
{
    [Authorize]
    public class ResponsController : Controller
    {
        private SocialConnectDBEntities db = new SocialConnectDBEntities();

        // GET: Respons
        [Authorize(Roles = "Admin")]
        public ActionResult Index()
        {
            var responses = db.Responses.Include(r => r.Message).Include(r => r.User);
            return View(responses.ToList());
        }

        // GET: Respons/Details/5
        [Authorize(Roles = "Admin")]
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Respons respons = db.Responses.Find(id);
            if (respons == null)
            {
                return HttpNotFound();
            }
            return View(respons);
        }

        // GET: Respons/Create
        [RenderAjaxPartialScripts]
        public ActionResult Create(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Message message = db.Messages.Find(id);
            if (message == null)
            {
                return HttpNotFound();
            }

            ViewBag.MessageId = new SelectList(db.Messages.Where(x=>x.MessageId == message.MessageId), "MessageId", "Subject");
            ViewBag.FromUserId = new SelectList(db.Users, "UserId", "FirstName");
            return PartialView();
        }

        // POST: Respons/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ResponseId,ReplyContent,Image")] Respons respons,Notification notify,HttpPostedFileBase image, int? id)
        {
            if (ModelState.IsValid)
            {
                string imageName = "";
                if(image != null)
                {
                    try
                    {
                        string ext = Path.GetExtension(image.FileName).ToLower();
                        string[] allowedExt = { ".png", ".gif", ".jpg", ".jpeg" };
                        if (allowedExt.Contains(ext))
                        {
                            imageName = Path.GetFileName(image.FileName).ToLower();
                            image.SaveAs(Server.MapPath("~/msgimg/" + imageName));
                            respons.Image = imageName;
                        }
                    }
                    catch (Exception)
                    {

                       
                    }
                }
                else
                {
                    respons.Image = "hide_img";
                }

                User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);
                Message messages = db.Messages.Find(id);
                respons.MessageId = messages.MessageId;
                respons.FromUserId = u.UserId;
                respons.DateSent = DateTime.Now;
                db.Responses.Add(respons);
                db.SaveChanges();

                notify.CurrentUserId = u.UserId;
                notify.NotifyUserId = respons.Message.FromUserId;
                notify.TypeId = 6;
                notify.NotifyContent = u.FullName + " responded to your message.";
                notify.NotifyDate = DateTime.Now;
                notify.IsViewed = false;
                notify.PostId = null;
                notify.MessageId = respons.MessageId;
                    
                
                db.Notifications.Add(notify);
                db.SaveChanges();

                return RedirectToAction("Index","Messages");
            }
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Message message = db.Messages.Find(id);
            if (message == null)
            {
                return HttpNotFound();
            }
            ViewBag.MessageId = new SelectList(db.Messages.Where(x=>x.MessageId == message.MessageId), "MessageId", "Subject", respons.MessageId);
            ViewBag.FromUserId = new SelectList(db.Users, "UserId", "FirstName", respons.FromUserId);
            return View(respons);
        }

        // GET: Respons/Edit/5
        [Authorize(Roles = "Admin")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Respons respons = db.Responses.Find(id);
            if (respons == null)
            {
                return HttpNotFound();
            }
            ViewBag.MessageId = new SelectList(db.Messages, "MessageId", "Subject", respons.MessageId);
            ViewBag.FromUserId = new SelectList(db.Users, "UserId", "FirstName", respons.FromUserId);
            return View(respons);
        }

        // POST: Respons/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult Edit([Bind(Include = "ResponseId,MessageId,FromUserId,ReplyContent,Image,DateSent")] Respons respons)
        {
            if (ModelState.IsValid)
            {
                db.Entry(respons).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.MessageId = new SelectList(db.Messages, "MessageId", "Subject", respons.MessageId);
            ViewBag.FromUserId = new SelectList(db.Users, "UserId", "FirstName", respons.FromUserId);
            return View(respons);
        }

        // GET: Respons/Delete/5
        [Authorize(Roles = "Admin")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Respons respons = db.Responses.Find(id);
            if (respons == null)
            {
                return HttpNotFound();
            }
            return View(respons);
        }

        // POST: Respons/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteConfirmed(int id)
        {
            Respons respons = db.Responses.Find(id);
            db.Responses.Remove(respons);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
