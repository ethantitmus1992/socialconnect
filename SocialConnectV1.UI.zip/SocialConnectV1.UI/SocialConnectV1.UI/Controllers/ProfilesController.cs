﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SocialConnectV1.DATA;
using SocialConnectV1.UI.Extensions;

namespace SocialConnectV1.UI.Controllers
{
    [Authorize]
    public class ProfilesController : Controller
    {
        private SocialConnectDBEntities db = new SocialConnectDBEntities();


        public JsonResult PokeUser(Guid profileId, string text)
        {
            Profile profiles = db.Profiles.Single(x => x.ProfileId == profileId);
            User u = db.Users.Single(x => x.Email == User.Identity.Name);

            if(u != null)
            {
                Poke poke = new Poke()
                {
                    ProfileId = profileId,
                    FromUserId = u.UserId,
                    DatePoked = DateTime.Now,
                    PokeText = text
                };

                db.Pokes.Add(poke);
                db.SaveChanges();

                Notification notify = new Notification()
                {
                    CurrentUserId = u.UserId,
                    NotifyUserId = profiles.UserId,
                    TypeId = 7,
                    NotifyContent = u.FullName + " poked you.",
                    NotifyDate = DateTime.Now,
                    IsViewed = false,
                    PostId = null,
                    MessageId = null
                };
                db.Notifications.Add(notify);
                db.SaveChanges();

                var data = new
                {
                    User = poke.User.FullName,
                    Date = string.Format("{0:M/d/yyyy @ hh:mm tt}", poke.DatePoked),
                    Text = poke.PokeText
                };
                return Json(data, JsonRequestBehavior.AllowGet);

            }
            return null;
        }


        // GET: Profiles
        public ActionResult Index()
        {
            User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);
            var profiles = db.Profiles.Where(x => x.UserId == u.UserId).Include(p => p.State).Include(p => p.User).ToList();
            return View(profiles);
        }

        // GET: Profiles/Details/5
        public ActionResult Details(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Profile profile = db.Profiles.Find(id);
            if (profile == null)
            {
                return HttpNotFound();
            }
            return View(profile);
        }

        [RenderAjaxPartialScripts]
        public ActionResult Create()
        {
            ViewBag.StateId = new SelectList(db.States, "StateID", "StateName");
            ViewBag.UserId = new SelectList(db.Users, "UserId", "FirstName");
            return PartialView();
        }

        // POST: Profiles/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ProfileId,DOB,About,PlacesWorked,Education,Hobbies,Music,TV,City,StateId,IsPublic")] Profile profile)
        {
            if (ModelState.IsValid)
            {
                User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);
                profile.UserId = u.UserId;
                profile.FullName = u.FullName;
                profile.ProfileId = Guid.NewGuid();
                db.Profiles.Add(profile);
                db.SaveChanges();
                return RedirectToAction("Index","Users");
            }

            ViewBag.StateId = new SelectList(db.States, "StateID", "StateName", profile.StateId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "FirstName", profile.UserId);
            return View(profile);
        }

        // GET: Profiles/Edit/5
        public ActionResult Edit(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Profile profile = db.Profiles.Find(id);
            if (profile == null)
            {
                return HttpNotFound();
            }
            ViewBag.StateId = new SelectList(db.States, "StateID", "StateName", profile.StateId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "FirstName", profile.UserId);
            return PartialView(profile);
        }

        // POST: Profiles/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ProfileId,UserId,FullName,DOB,About,PlacesWorked,Education,Hobbies,Music,TV,City,StateId,IsPublic")] Profile profile)
        {
            if (ModelState.IsValid)
            {
                db.Entry(profile).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index","Users");
            }
            ViewBag.StateId = new SelectList(db.States, "StateID", "StateName", profile.StateId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "FirstName", profile.UserId);
            return View(profile);
        }


        [Authorize]
        public ActionResult Public(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Profile profile = db.Profiles.Find(id);
            if (profile == null)
            {
                return HttpNotFound();
            }
            return PartialView(profile);
        }

        // POST: Profiles/Delete/5
        [HttpPost, ActionName("Public")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult PublicConfirmed(Guid id)
        {
            Profile profile = db.Profiles.Find(id);
            if (profile.IsPublic == false)
            {
                profile.IsPublic = true;
            }
            else
            {
                profile.IsPublic = false;
            }



            db.SaveChanges();
            return RedirectToAction("Index", "Users");
        }




        // GET: Profiles/Delete/5
        [Authorize(Roles = "Admin")]
        public ActionResult Delete(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Profile profile = db.Profiles.Find(id);
            if (profile == null)
            {
                return HttpNotFound();
            }
            return PartialView(profile);
        }

        // POST: Profiles/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteConfirmed(Guid id)
        {
            Profile profile = db.Profiles.Find(id);
            db.Profiles.Remove(profile);
            db.SaveChanges();
            return RedirectToAction("AllUsers","Users");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
