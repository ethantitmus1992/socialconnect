﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SocialConnectV1.DATA;
using SocialConnectV1.UI.Extensions;

namespace SocialConnectV1.UI.Controllers
{
    public class BookmarksController : Controller
    {
        private SocialConnectDBEntities db = new SocialConnectDBEntities();

        // GET: Bookmarks
        [Authorize]
        public ActionResult Index()
        {
            User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);

            var bookmarks = db.Bookmarks.Where(x=>x.UserId == u.UserId).Include(b => b.Post).Include(b => b.User);
            return View(bookmarks.ToList());
        }

        // GET: Bookmarks/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Bookmark bookmark = db.Bookmarks.Find(id);
            if (bookmark == null)
            {
                return HttpNotFound();
            }
            return View(bookmark);
        }

        // GET: Bookmarks/Create
        [Authorize]
        public ActionResult Create(Guid? id)
        {
            if(id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Post post = db.Posts.Find(id);
            if(post == null)
            {
                return HttpNotFound();
            }

            ViewBag.PostId = new SelectList(db.Posts.Where(x=>x.PostId == post.PostId), "PostId", "PostContent");
            ViewBag.UserId = new SelectList(db.Users, "UserId", "FirstName");
            return PartialView();
        }

        // POST: Bookmarks/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult Create([Bind(Include = "BookmarkId,PostId")] Bookmark bookmark, Guid? id)
        {
            if (ModelState.IsValid)
            {
                User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);
                bookmark.UserId = u.UserId;
                bookmark.MarkedDate = DateTime.Now;

                db.Bookmarks.Add(bookmark);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Post post = db.Posts.Find(id);
            if (post == null)
            {
                return HttpNotFound();
            }

            ViewBag.PostId = new SelectList(db.Posts.Where(x => x.PostId == post.PostId), "PostId", "PostContent", bookmark.PostId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "FirstName", bookmark.UserId);
            return View(bookmark);
        }

        // GET: Bookmarks/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Bookmark bookmark = db.Bookmarks.Find(id);
            if (bookmark == null)
            {
                return HttpNotFound();
            }
            ViewBag.PostId = new SelectList(db.Posts, "PostId", "PostContent", bookmark.PostId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "FirstName", bookmark.UserId);
            return View(bookmark);
        }

        // POST: Bookmarks/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "BookmarkId,UserId,PostId,MarkedDate")] Bookmark bookmark)
        {
            if (ModelState.IsValid)
            {
                db.Entry(bookmark).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.PostId = new SelectList(db.Posts, "PostId", "PostContent", bookmark.PostId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "FirstName", bookmark.UserId);
            return View(bookmark);
        }

        // GET: Bookmarks/Delete/5
        [Authorize]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Bookmark bookmark = db.Bookmarks.Find(id);
            if (bookmark == null)
            {
                return HttpNotFound();
            }
            return PartialView(bookmark);
        }

        // POST: Bookmarks/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult DeleteConfirmed(int id)
        {
            Bookmark bookmark = db.Bookmarks.Find(id);
            db.Bookmarks.Remove(bookmark);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
