﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SocialConnectV1.DATA;

namespace SocialConnectV1.UI.Controllers
{
    public class NotificationsController : Controller
    {
        private SocialConnectDBEntities db = new SocialConnectDBEntities();

        // GET: Notifications
        [Authorize]
        public ActionResult Index(int? SelectedType)
        {
            var types = db.Types.OrderBy(x => x.TypeId).ToList();
            ViewBag.SelectedType = new SelectList(types, "TypeId", "Name", SelectedType);
            int typeId = SelectedType.GetValueOrDefault();

            User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);

            IQueryable<Notification> notification = db.Notifications.Where(x => !SelectedType.HasValue || x.TypeId == typeId)
                .Where(x => x.NotifyUserId == u.UserId).OrderBy(d => d.TypeId).OrderByDescending(x => x.NotifyDate);
            var notifications = notification.ToList();

            return View(notifications);
        }
        [Authorize]
        public ActionResult Notifications()
        {
            User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);
            var notifications = db.Notifications.Where(x => x.NotifyUserId == u.UserId && x.IsViewed == false).OrderByDescending(x => x.NotifyDate).ToList();

            var count = (from a in db.Notifications
                         where a.NotifyUserId == u.UserId && a.IsViewed == false
                         select a).Count();
            ViewBag.Cnt = count;

            return PartialView(notifications);
        }

        public ActionResult NotifyCount()
        {
            User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);
            var count = (from a in db.Notifications
                         where a.NotifyUserId == u.UserId && a.IsViewed == false
                         select a).Count();
            ViewBag.Count = count;
            return PartialView();
        }

        public ActionResult NewType()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult NewType([Bind(Include ="TypeId,Name")] DATA.Type type)
        {
            if (ModelState.IsValid)
            {
                db.Types.Add(type);
                db.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(type);
        }


        // GET: Notifications/Details/5
        [Authorize]
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Notification notification = db.Notifications.Find(id);
            notification.IsViewed = true;
            db.SaveChanges();
            if (notification == null)
            {
                return HttpNotFound();
            }
            return View(notification);
        }

        // GET: Notifications/Create
        [Authorize(Roles = "Admin")]
        public ActionResult Create()
        {
            ViewBag.TypeId = new SelectList(db.Types, "TypeId", "Name");
            ViewBag.CurrentUserId = new SelectList(db.Users, "UserId", "FirstName");
            ViewBag.NotifyUserId = new SelectList(db.Users, "UserId", "FirstName");
            ViewBag.MessageId = new SelectList(db.Messages, "MessageId", "Subject");
            ViewBag.PostId = new SelectList(db.Posts, "PostId", "PostContent");
            return View();
        }

        // POST: Notifications/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles ="Admin")]
        public ActionResult Create([Bind(Include = "NotificationId,CurrentUserId,NotifyUserId,TypeId,NotifyContent,NotifyDate,IsViewed,PostId,MessageId")] Notification notification)
        {
            if (ModelState.IsValid)
            {
                db.Notifications.Add(notification);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.TypeId = new SelectList(db.Types, "TypeId", "Name", notification.TypeId);
            ViewBag.CurrentUserId = new SelectList(db.Users, "UserId", "FirstName", notification.CurrentUserId);
            ViewBag.NotifyUserId = new SelectList(db.Users, "UserId", "FirstName", notification.NotifyUserId);
            ViewBag.MessageId = new SelectList(db.Messages, "MessageId", "Subject", notification.MessageId);
            ViewBag.PostId = new SelectList(db.Posts, "PostId", "PostContent", notification.PostId);
            return View(notification);
        }

        // GET: Notifications/Edit/5
        [Authorize(Roles = "Admin")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Notification notification = db.Notifications.Find(id);
            if (notification == null)
            {
                return HttpNotFound();
            }
            ViewBag.TypeId = new SelectList(db.Types, "TypeId", "Name", notification.TypeId);
            ViewBag.CurrentUserId = new SelectList(db.Users, "UserId", "FirstName", notification.CurrentUserId);
            ViewBag.NotifyUserId = new SelectList(db.Users, "UserId", "FirstName", notification.NotifyUserId);
            ViewBag.MessageId = new SelectList(db.Messages, "MessageId", "Subject", notification.MessageId);
            ViewBag.PostId = new SelectList(db.Posts, "PostId", "PostContent", notification.PostId);
            return View(notification);
        }

        // POST: Notifications/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult Edit([Bind(Include = "NotificationId,CurrentUserId,NotifyUserId,TypeId,NotifyContent,NotifyDate,IsViewed,PostId,MessageId")] Notification notification)
        {
            if (ModelState.IsValid)
            {
                db.Entry(notification).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.TypeId = new SelectList(db.Types, "TypeId", "Name", notification.TypeId);
            ViewBag.CurrentUserId = new SelectList(db.Users, "UserId", "FirstName", notification.CurrentUserId);
            ViewBag.NotifyUserId = new SelectList(db.Users, "UserId", "FirstName", notification.NotifyUserId);
            ViewBag.MessageId = new SelectList(db.Messages, "MessageId", "Subject", notification.MessageId);
            ViewBag.PostId = new SelectList(db.Posts, "PostId", "PostContent", notification.PostId);
            return View(notification);
        }

        // GET: Notifications/Delete/5
        [Authorize(Roles = "Admin")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Notification notification = db.Notifications.Find(id);
            if (notification == null)
            {
                return HttpNotFound();
            }
            return View(notification);
        }

        // POST: Notifications/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteConfirmed(int id)
        {
            Notification notification = db.Notifications.Find(id);
            db.Notifications.Remove(notification);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
