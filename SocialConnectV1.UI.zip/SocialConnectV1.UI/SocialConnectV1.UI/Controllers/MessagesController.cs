﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SocialConnectV1.DATA;
using System.IO;
using SocialConnectV1.UI.Extensions;

namespace SocialConnectV1.UI.Controllers
{
    [Authorize]
    public class MessagesController : Controller
    {
        private SocialConnectDBEntities db = new SocialConnectDBEntities();


       



        // GET: Messages
        public ActionResult Index()
        {
            User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);

            var messages = db.Messages.Where(x=>x.ToUserId == u.UserId).OrderByDescending(x=>x.DateSent).ToList();
            return View(messages);
        }

        [HttpPost]
        public ActionResult Index(FormCollection fc)
        {
            string[] ids = fc["InboxId"].Split(new char[] { ',' });
            foreach(string id in ids)
            {
                var inbox = db.Messages.Find(int.Parse(id));
                if(inbox.IsRead == false)
                {
                    inbox.IsRead = true;
                }
                else if(inbox.IsRead == true)
                {
                    inbox.IsRead = true;
                }

                db.SaveChanges();
            }

            return RedirectToAction("Index");
        }

        public ActionResult Sent()
        {
            User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);
            var messages = db.Messages.Where(x => x.FromUserId == u.UserId).OrderByDescending(x => x.DateSent).ToList();
            return View(messages);

        }

        

        public ActionResult MsgCount()
        {
            User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);
            var count = (from a in db.Messages
                         where a.ToUserId == u.UserId && a.IsRead == false
                         select a).Count();
            ViewBag.Msg = count;
            return PartialView();
        }


        public ActionResult SentDetails(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Message message = db.Messages.Find(id);
            db.SaveChanges();
            if (message == null)
            {
                return HttpNotFound();
            }
            return View(message);
        }

      


        // GET: Messages/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Message message = db.Messages.Find(id);
            message.IsRead = true;
            message.ViewedDate = DateTime.Now;
            db.SaveChanges();
            if (message == null)
            {
                return HttpNotFound();
            }
            return View(message);
        }

        // GET: Messages/Create
        [RenderAjaxPartialScripts]
        public ActionResult Create(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }

            ViewBag.FromUserId = new SelectList(db.Users, "UserId", "FirstName");
            ViewBag.ToUserId = new SelectList(db.Users.Where(x=>x.UserId == user.UserId), "UserId", "FullName");
            return PartialView();
        }

        // POST: Messages/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "MessageId,ToUserId,Subject,Body,Image")] Message message, HttpPostedFileBase image, int? id)
        {
            if (ModelState.IsValid)
            {
                string imgName = "";
                if (image != null)
                {
                    try
                    {
                        string ext = Path.GetExtension(image.FileName).ToLower();
                        string[] allowedExt = { ".png", ".gif", ".jpg", ".jpeg" };
                        if (allowedExt.Contains(ext))
                        {
                            imgName = Path.GetFileName(image.FileName).ToLower();
                            image.SaveAs(Server.MapPath("~/msgimg/" + imgName));
                            message.Image = imgName;
                        }
                    }
                    catch (Exception)
                    {

                        
                    }
                }
                else
                {
                    message.Image = "hide_img";
                }

                User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);
                message.FromUserId = u.UserId;
                message.IsRead = false;
                message.DateSent = DateTime.Now;
                message.ViewedDate = null;
                db.Messages.Add(message);
                db.SaveChanges();

               
               

                return RedirectToAction("Index");
            }
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            ViewBag.FromUserId = new SelectList(db.Users, "UserId", "FirstName", message.FromUserId);
            ViewBag.ToUserId = new SelectList(db.Users.Where(x=>x.UserId == user.UserId), "UserId", "FullName", message.ToUserId);
            return View(message);
        }


        public ActionResult NewMsg()
        {
            

            ViewBag.FromUserId = new SelectList(db.Users, "UserId", "FirstName");
            ViewBag.ToUserId = new SelectList(db.Users.ToList(), "UserId", "FullName");
            return View();
        }

        // POST: Messages/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult NewMsg([Bind(Include = "MessageId,ToUserId,Subject,Body,Image")] Message message, HttpPostedFileBase image, int[] selectedUsers)
        {
            if (ModelState.IsValid)
            {
                User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);
                if(selectedUsers != null)
                {

                foreach(var x in selectedUsers)
                    {

                    

                string imgName = "";
                if (image != null)
                {
                    try
                    {
                        string ext = Path.GetExtension(image.FileName).ToLower();
                        string[] allowedExt = { ".png", ".gif", ".jpg", ".jpeg" };
                        if (allowedExt.Contains(ext))
                        {
                            imgName = Path.GetFileName(image.FileName).ToLower();
                            image.SaveAs(Server.MapPath("~/msgimg/" + imgName));
                            message.Image = imgName;
                        }
                    }
                    catch (Exception)
                    {


                    }
                }
                else
                {
                    message.Image = "hide_img";
                }

                        Message newMsg = new Message()
                        {
                            FromUserId = u.UserId,
                            ToUserId = x,
                            Subject = message.Subject,
                            Body = message.Body,
                            DateSent = DateTime.Now,
                            ViewedDate = null,
                            IsRead = false,
                            Image = message.Image
                        };
                
               
                db.Messages.Add(newMsg);
                db.SaveChanges();

                       
                    }
                }
                return RedirectToAction("Index");
            }
            
            ViewBag.FromUserId = new SelectList(db.Users, "UserId", "FirstName", message.FromUserId);
            ViewBag.ToUserId = new SelectList(db.Users.ToList(), "UserId", "FullName", message.ToUserId);
            return View(message);
        }



        // GET: Messages/Edit/5
        [Authorize(Roles = "Admin")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Message message = db.Messages.Find(id);
            if (message == null)
            {
                return HttpNotFound();
            }
            ViewBag.FromUserId = new SelectList(db.Users, "UserId", "FirstName", message.FromUserId);
            ViewBag.ToUserId = new SelectList(db.Users, "UserId", "FirstName", message.ToUserId);
            return View(message);
        }

        // POST: Messages/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult Edit([Bind(Include = "MessageId,FromUserId,ToUserId,Subject,Body,Image,DateSent,IsRead,ViewedDate")] Message message)
        {
            if (ModelState.IsValid)
            {
                db.Entry(message).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.FromUserId = new SelectList(db.Users, "UserId", "FirstName", message.FromUserId);
            ViewBag.ToUserId = new SelectList(db.Users, "UserId", "FirstName", message.ToUserId);
            return View(message);
        }

        // GET: Messages/Delete/5
        [Authorize(Roles = "Admin")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Message message = db.Messages.Find(id);
            if (message == null)
            {
                return HttpNotFound();
            }
            return View(message);
        }

        // POST: Messages/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteConfirmed(int id)
        {
            Message message = db.Messages.Find(id);
            db.Messages.Remove(message);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
