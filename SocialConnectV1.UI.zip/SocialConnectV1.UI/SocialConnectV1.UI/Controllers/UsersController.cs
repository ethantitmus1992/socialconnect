﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SocialConnectV1.DATA;
using IdentitySample.Models;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.AspNet.Identity;
using System.Net.Mail;
using System.IO;

namespace SocialConnectV1.UI.Controllers
{
    public class UsersController : Controller
    {
        private SocialConnectDBEntities db = new SocialConnectDBEntities();


        public JsonResult AddFriend(int friendId)
        {
            User friend = db.Users.Single(x => x.UserId == friendId);
            User u = db.Users.Single(x => x.Email == User.Identity.Name);

            if(u != null)
            {
                Friend newFriend = new Friend()
                {
                    User1Id = friendId,
                    User2Id = u.UserId,
                    FriendStatusId = 1
                };

                db.Friends.Add(newFriend);
                db.SaveChanges();

                Notification notify = new Notification()
                {
                    CurrentUserId = u.UserId,
                    NotifyUserId = friendId,
                    TypeId = 8,
                    NotifyContent = u.FullName + " sent you a friend request.",
                    NotifyDate = DateTime.Now,
                    IsViewed = false,
                    PostId = null,
                    MessageId = null
                };

                db.Notifications.Add(notify);
                db.SaveChanges();

                var data = new
                {
                    FromUser = newFriend.User1.FullName
                };
                return Json(data, JsonRequestBehavior.AllowGet);
            }
            return null;
        }




        // GET: Users
        [Authorize]
        public ActionResult Index()
        {
            User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);
            var user = db.Users.Where(x => x.UserId == u.UserId).ToList();

            return View(user);
        }


        public ActionResult AllUsers()
        {
            var user = db.Users.OrderBy(x => x.LastName).Include(x => x.Profiles).ToList();
            return View(user);
        }


        public ActionResult CheckEmail()
        {
            var user = db.Users.ToList();
            return View(user);
        }

        public List<User> GetUser(string searchString)
        {
            var user = db.Users.Where(x => x.FirstName.Contains(searchString) || x.LastName.Contains(searchString)).OrderBy(x => x.LastName).ToList();
            return user;
        }

        public ActionResult UserSearch(string q)
        {
            var results = GetUser(q);
            return PartialView(results);
        }

        // GET: Users/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        // GET: Users/Create
        public ActionResult Create()
        {
            var RoleManager = HttpContext.GetOwinContext().Get<ApplicationRoleManager>();
            ViewBag.RoleId = new SelectList(RoleManager.Roles.ToList(), "Name", "Name");

            return View();
        }

        // POST: Users/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "UserId,FirstName,LastName,Email,Password,ConfirmPassword,ProfilePhoto")] User user, HttpPostedFileBase profilePhoto, string[] selectedRoles)
        {
            if (ModelState.IsValid)
            {

#region Identity Config & Email Confirmation
                var userManager = System.Web.HttpContext.Current.GetOwinContext().GetUserManager<ApplicationUserManager>();
                var newUser = new ApplicationUser()
                {
                    UserName = user.Email,
                    Email = user.Email
                };

                var password = user.ConfirmPassword;
                userManager.Create(newUser, password);

                if (selectedRoles != null)
                {
                    userManager.AddToRoles(newUser.Id, selectedRoles);
                }
                else
                {
                    userManager.AddToRole(newUser.Id, "User");
                }

                user.AspId = newUser.Id;

                var code = userManager.GenerateEmailConfirmationToken(user.AspId);
                var callbackUrl = Url.Action("ConfirmEmail", "Account", new { userId = user.AspId, code = code }, protocol: Request.Url.Scheme);
                string body = string.Format("Thankyou for taking the time to get Connected!\nYour membership is a big deal for us and is greatly appreciated!\nJust click the link below to confirm your account.\n\nSincerely,\nEthan Titmus\n\n{0}", callbackUrl);
                MailMessage m = new MailMessage("etd3v3lopm3nt@gmail.com", user.Email, "Social Connect Email Confirmation", body);
                using (SmtpClient client = new SmtpClient())
                {
                    client.EnableSsl = true;
                    client.UseDefaultCredentials = false;
                    client.Credentials = new System.Net.NetworkCredential("etd3v3lopm3nt@gmail.com", "5344708Ejt@");
                    client.Host = "smtp.gmail.com";
                    client.Port = 587;
                    client.DeliveryMethod = SmtpDeliveryMethod.Network;
                    client.Send(m);

                }

                #endregion


                string imgName = "";
                if(profilePhoto != null)
                {
                    try
                    {
                        string ext = Path.GetExtension(profilePhoto.FileName).ToLower();
                        string[] allowedExt = { ".png", ".gif", ".jpg", ".jpeg" };
                        if (allowedExt.Contains(ext))
                        {
                            imgName = Path.GetFileName(profilePhoto.FileName).ToLower();
                            profilePhoto.SaveAs(Server.MapPath("~/userimg/" + imgName));
                            user.ProfilePhoto = imgName;
                        }
                    }
                    catch (Exception)
                    {

                        
                    }
                }
                else
                {
                    user.ProfilePhoto = "user.png";
                }


                user.SignUpDate = DateTime.Now;
                db.Users.Add(user);
                db.SaveChanges();

          

                return RedirectToAction("CheckEmail");
            }
            var RoleManager = HttpContext.GetOwinContext().Get<ApplicationRoleManager>();
            ViewBag.RoleId = new SelectList(RoleManager.Roles.ToList(), "Name", "Name");

            return View(user);
        }

        // GET: Users/Edit/5
        [Authorize]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        // POST: Users/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult Edit([Bind(Include = "UserId,FirstName,LastName,Email,Password,ConfirmPassword,AspId,SignUpDate,ProfilePhoto")] User user, HttpPostedFileBase profilePhoto)
        {
            if (ModelState.IsValid)
            {
                string imgName = user.ProfilePhoto;
                if(profilePhoto != null)
                {
                    string ext = Path.GetExtension(profilePhoto.FileName).ToLower();
                    string[] allowedExt = { ".png", ".gif", ".jpg", ".jpeg" };
                    if (allowedExt.Contains(ext))
                    {
                        imgName = Path.GetFileName(profilePhoto.FileName).ToLower();
                        profilePhoto.SaveAs(Server.MapPath("~/userimg/" + imgName));
                        user.ProfilePhoto = imgName;
                    }
                }


                db.Entry(user).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(user);
        }



        // GET: Users/Delete/5
        [Authorize(Roles = "Admin")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        // POST: Users/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteConfirmed(int id)
        {
            User user = db.Users.Find(id);
            db.Users.Remove(user);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
