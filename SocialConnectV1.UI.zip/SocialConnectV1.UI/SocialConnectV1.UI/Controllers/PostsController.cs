﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SocialConnectV1.DATA;
using System.IO;
using SocialConnectV1.UI.Extensions;

namespace SocialConnectV1.UI.Controllers
{
    public class PostsController : Controller
    {
        private SocialConnectDBEntities db = new SocialConnectDBEntities();


        public JsonResult AddComment(Guid postId, string content)
        {
            Post post = db.Posts.Single(x => x.PostId == postId);
            User u = db.Users.Single(x => x.Email == User.Identity.Name);
            if(u != null)
            {
                Comment newCom = new Comment()
                {
                    PostId = postId,
                    UserId = u.UserId,
                    DateAdded = DateTime.Now,
                    Body = content
                };

                db.Comments.Add(newCom);
                db.SaveChanges();

                Notification notify = new Notification()
                {
                    CurrentUserId = u.UserId,
                    NotifyUserId = post.UserId,
                    TypeId = 1,
                    NotifyContent = u.FullName + " commented on your post.",
                    NotifyDate = DateTime.Now,
                    IsViewed = false,
                    PostId = postId,
                    MessageId = null
                };
                db.Notifications.Add(notify);
                db.SaveChanges();

                var data = new
                {
                    Comments = newCom.Body,
                    CUser = newCom.User.FullName,
                    Date = string.Format("{0:dd MMM yyy - hh:mm tt}", newCom.DateAdded)
                };
                return Json(data, JsonRequestBehavior.AllowGet);
            }
            return null;
        }


        public JsonResult AddPostLike(Guid postId, string like)
        {
            Post post = db.Posts.Single(x => x.PostId == postId);
            User u = db.Users.Single(x => x.Email == User.Identity.Name);

            if(u != null)
            {
                PostLike newLike = new PostLike()
                {
                    PostId = postId,
                    UserId = u.UserId,
                    DateAdded = DateTime.Now,
                    LikeText = like
                };
                db.PostLikes.Add(newLike);
                db.SaveChanges();

                Notification notify = new Notification()
                {
                    CurrentUserId = u.UserId,
                    NotifyUserId = post.UserId,
                    TypeId = 2,
                    NotifyContent = u.FullName + " liked your post.",
                    NotifyDate = DateTime.Now,
                    IsViewed = false,
                    PostId = postId,
                    MessageId = null
                };

                db.Notifications.Add(notify);
                db.SaveChanges();

                var data = new
                {
                    LUser = newLike.User.FullName,
                    Date = string.Format("{0:dd MMM yyy - hh:mm tt}", newLike.DateAdded),
                    Text = newLike.LikeText
                };
                return Json(data, JsonRequestBehavior.AllowGet);
            }
            return null;

        }


        public JsonResult AddComReply(int commentId, string content)
        {
            Comment com = db.Comments.Single(x => x.CommentId == commentId);
            User u = db.Users.Single(x => x.Email == User.Identity.Name);

            if(u != null)
            {
                CommentReply reply = new CommentReply()
                {
                    CommentId = commentId,
                    UserId = u.UserId,
                    DateAdded = DateTime.Now,
                    ReplyContent = content
                };
                db.CommentReplies.Add(reply);
                db.SaveChanges();

                Notification notify = new Notification()
                {
                    CurrentUserId = u.UserId,
                    NotifyUserId = com.UserId,
                    TypeId = 3,
                    NotifyContent = u.FullName + " replied to your comment.",
                    NotifyDate = DateTime.Now,
                    IsViewed = false,
                    PostId = com.Post.PostId,
                    MessageId = null
                };

                db.Notifications.Add(notify);
                db.SaveChanges();


                var data = new
                {
                    RUser = reply.User.FullName,
                    Replies = reply.ReplyContent,
                    Date = string.Format("{0:dd MMM yyy - hh:mm tt}", reply.DateAdded)
                };
                return Json(data, JsonRequestBehavior.AllowGet);
            }
            return null;
        }

        public JsonResult AddComLike(int commentId, string like)
        {
            Comment com = db.Comments.Single(x => x.CommentId == commentId);
            User u = db.Users.Single(x => x.Email == User.Identity.Name);

            if(u != null)
            {
                CommentLike lik = new CommentLike()
                {
                    CommentId = commentId,
                    UserId = u.UserId,
                    DateAdded = DateTime.Now,
                    LikeText = like
                };
                db.CommentLikes.Add(lik);
                db.SaveChanges();

                Notification notify = new Notification()
                {
                    CurrentUserId = u.UserId,
                    NotifyUserId = com.UserId,
                    TypeId = 4,
                    NotifyContent = u.FullName + " liked your comment.",
                    NotifyDate = DateTime.Now,
                    IsViewed = false,
                    PostId = com.Post.PostId,
                    MessageId = null
                };

                db.Notifications.Add(notify);
                db.SaveChanges();

                var data = new
                {
                    CLUser = lik.User.FullName,
                    Date = string.Format("{0:dd MMM yyy - hh:mm tt}", lik.DateAdded),
                    Text = lik.LikeText
                };
                return Json(data, JsonRequestBehavior.AllowGet);
            }
            return null;
        }

       

      


        // GET: Posts
        public ActionResult Index()
        {
            var posts = db.Posts.Where(x=>x.IsRemoved == false).OrderByDescending(x => x.PostDate).Include(p => p.PostBackground).Include(p => p.User).ToList();
            return View(posts);
        }

        public ActionResult TrendingPosts()
        {
            var posts = GetPopularPosts(5);

            return PartialView(posts);
        }


        private List<Post> GetPopularPosts(int count)
        {
            return db.Posts
                .Where(x => x.IsRemoved == false)
                .OrderByDescending(x => x.PostLikes.Count())
                .Take(count)
                .ToList();
        }

        public List<Post> GetPosts(string searchString)
        {
            var post = db.Posts.Where(x => x.PostContent.Contains(searchString) || x.User.FirstName.Contains(searchString) || x.User.LastName.Contains(searchString)).Where(x => x.IsRemoved == false).OrderByDescending(x => x.PostDate).ToList();
            return post;
        }

        public ActionResult PostSearch(string q)
        {
            var results = GetPosts(q);
            return PartialView(results);
        }


        // GET: Posts/Details/5
        public ActionResult Details(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Post post = db.Posts.Find(id);
            if (post == null)
            {
                return HttpNotFound();
            }
            return View(post);
        }

        [Authorize(Roles ="Admin")]
        public ActionResult NewBG()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult NewBG([Bind(Include ="PostBackgroundId,Name,ClassName")] PostBackground postBackground)
        {
            if (ModelState.IsValid)
            {
                db.PostBackgrounds.Add(postBackground);
                db.SaveChanges();
                return RedirectToAction("Index","Posts");
            }
            return View(postBackground);
        }


        // GET: Posts/Create
        [Authorize]
        [RenderAjaxPartialScripts]
        public ActionResult Create()
        {
            ViewBag.PostBackgroundId = new SelectList(db.PostBackgrounds.ToList(), "PostBackgroundId", "Name");
            ViewBag.UserId = new SelectList(db.Users, "UserId", "FirstName");
            return PartialView();
        }

        // POST: Posts/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult Create([Bind(Include = "PostId,PostContent,PostBackgroundId,PostImage")] Post post, HttpPostedFileBase postImage)
        {
            if (ModelState.IsValid)
            {

                string imgName = "";
                if(postImage != null)
                {
                    try
                    {
                        string ext = Path.GetExtension(postImage.FileName).ToLower();
                        string[] allowedExt = { ".png", ".gif", ".jpg", ".jpeg" };
                        if (allowedExt.Contains(ext))
                        {
                            imgName = Path.GetFileName(postImage.FileName).ToLower();
                            postImage.SaveAs(Server.MapPath("~/postimg/" + imgName));
                            post.PostImage = imgName;
                        }
                    }
                    catch (Exception)
                    {

                        
                    }
                }
                else
                {
                    post.PostImage = "hide_img";
                }

                var postContent = "";
                if(post.PostContent == null)
                {
                    post.PostContent = postContent;
                }

                User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);
                post.UserId = u.UserId;
                post.PostDate = DateTime.Now;
                post.IsRemoved = false;
                post.PostId = Guid.NewGuid();
                db.Posts.Add(post);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.PostBackgroundId = new SelectList(db.PostBackgrounds.ToList(), "PostBackgroundId", "Name", post.PostBackgroundId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "FirstName", post.UserId);
            return View(post);
        }

        // GET: Posts/Edit/5
        [Authorize]
        [RenderAjaxPartialScripts]
        public ActionResult Edit(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Post post = db.Posts.Find(id);
            if (post == null)
            {
                return HttpNotFound();
            }
            ViewBag.PostBackgroundId = new SelectList(db.PostBackgrounds.ToList(), "PostBackgroundId", "Name", post.PostBackgroundId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "FirstName", post.UserId);
            return PartialView(post);
        }

        // POST: Posts/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult Edit([Bind(Include = "PostId,UserId,PostContent,PostBackgroundId,PostImage")] Post post, HttpPostedFileBase postImage)
        {
            if (ModelState.IsValid)
            {
                string imageName = post.PostImage;
                if(postImage != null)
                {
                    string ext = Path.GetExtension(postImage.FileName).ToLower();
                    string[] allowedExt = { ".png", ".gif", ".jpg", ".jpeg" };
                    if (allowedExt.Contains(ext))
                    {
                        imageName = Path.GetFileName(postImage.FileName).ToLower();
                        postImage.SaveAs(Server.MapPath("~/postimg/" + imageName));
                        post.PostImage = imageName;
                    }
                }

                post.PostDate = DateTime.Now;


                db.Entry(post).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.PostBackgroundId = new SelectList(db.PostBackgrounds.ToList(), "PostBackgroundId", "Name", post.PostBackgroundId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "FirstName", post.UserId);
            return View(post);
        }





        // GET: Posts/Delete/5
        [Authorize]
        public ActionResult Delete(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Post post = db.Posts.Find(id);
            if (post == null)
            {
                return HttpNotFound();
            }
            return PartialView(post);
        }

        // POST: Posts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult DeleteConfirmed(Guid id)
        {
            Post post = db.Posts.Find(id);
            if(post.IsRemoved == false)
            {
                post.IsRemoved = true;
            }

            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
