﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SocialConnectV1.DATA;
using System.IO;
using SocialConnectV1.UI.Extensions;

namespace SocialConnectV1.UI.Controllers
{
    [Authorize]
    public class UserPhotoesController : Controller
    {
        private SocialConnectDBEntities db = new SocialConnectDBEntities();

        // GET: UserPhotoes
        [Authorize]
        public ActionResult Index()
        {
            User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);
            var userPhotos = db.UserPhotos.Where(x=>x.UserId == u.UserId);
            return View(userPhotos.ToList());
        }

        // GET: UserPhotoes/Details/5
        [Authorize(Roles = "Admin")]
        public ActionResult Details(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserPhoto userPhoto = db.UserPhotos.Find(id);
            if (userPhoto == null)
            {
                return HttpNotFound();
            }
            return View(userPhoto);
        }

        [RenderAjaxPartialScripts]
        public ActionResult Create(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Profile profile = db.Profiles.Find(id);
            if (profile == null)
            {
                return HttpNotFound();
            }

            ViewBag.ProfileId = new SelectList(db.Profiles.Where(x=>x.ProfileId == profile.ProfileId), "ProfileId", "FullName");
            ViewBag.UserId = new SelectList(db.Users, "UserId", "FirstName");
            return PartialView();
        }

        // POST: UserPhotoes/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "UserPhotoId,ProfileId,Image,Caption,IsPublic")] UserPhoto userPhoto, HttpPostedFileBase image, Guid? id)
        {
            if (ModelState.IsValid)
            {

                string imgName = "";
                if(image != null)
                {
                    try
                    {
                        string ext = Path.GetExtension(image.FileName).ToLower();
                        string[] allowedExt = { ".png", ".gif", ".jpg", ".jpeg" };
                        if (allowedExt.Contains(ext))
                        {
                            imgName = Path.GetFileName(image.FileName).ToLower();
                            image.SaveAs(Server.MapPath("~/userphotos/" + imgName));
                            userPhoto.Image = imgName;
                        }
                    }
                    catch (Exception)
                    {

                       
                    }
                }


                User u = db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);
                userPhoto.UserId = u.UserId;
                userPhoto.DateAdded = DateTime.Now;
                userPhoto.IsProfileImage = false;
                userPhoto.UserPhotoId = Guid.NewGuid();
                db.UserPhotos.Add(userPhoto);
                db.SaveChanges();
                return RedirectToAction("Index", "Users");
            }
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Profile profile = db.Profiles.Find(id);
            if (profile == null)
            {
                return HttpNotFound();
            }
            ViewBag.ProfileId = new SelectList(db.Profiles.Where(x => x.ProfileId == profile.ProfileId), "ProfileId", "FullName", userPhoto.ProfileId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "FirstName", userPhoto.UserId);
            return View(userPhoto);
        }

        // GET: UserPhotoes/Edit/5
        [Authorize(Roles = "Admin")]
        public ActionResult Edit(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserPhoto userPhoto = db.UserPhotos.Find(id);
            if (userPhoto == null)
            {
                return HttpNotFound();
            }
            ViewBag.ProfileId = new SelectList(db.Profiles, "ProfileId", "FullName", userPhoto.ProfileId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "FirstName", userPhoto.UserId);
            return View(userPhoto);
        }

        // POST: UserPhotoes/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult Edit([Bind(Include = "UserPhotoId,Image,Caption,DateAdded,UserId,ProfileId,IsProfileImage,IsPublic")] UserPhoto userPhoto)
        {
            if (ModelState.IsValid)
            {
                db.Entry(userPhoto).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.ProfileId = new SelectList(db.Profiles, "ProfileId", "FullName", userPhoto.ProfileId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "FirstName", userPhoto.UserId);
            return View(userPhoto);
        }


        public ActionResult Public(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserPhoto userPhoto = db.UserPhotos.Find(id);
            if (userPhoto == null)
            {
                return HttpNotFound();
            }
            return PartialView(userPhoto);
        }

        // POST: UserPhotoes/Delete/5
        [HttpPost, ActionName("Public")]
        [ValidateAntiForgeryToken]
        public ActionResult PublicConfirmed(Guid id)
        {
            UserPhoto userPhoto = db.UserPhotos.Find(id);
            if(userPhoto.IsPublic == false)
            {
                userPhoto.IsPublic = true;
            }
            else
            {
                userPhoto.IsPublic = false;
            }
            db.SaveChanges();
            return RedirectToAction("Index", "Users");
        }


        // GET: UserPhotoes/Delete/5
        public ActionResult Delete(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserPhoto userPhoto = db.UserPhotos.Find(id);
            if (userPhoto == null)
            {
                return HttpNotFound();
            }
            return PartialView(userPhoto);
        }

        // POST: UserPhotoes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(Guid id)
        {
            UserPhoto userPhoto = db.UserPhotos.Find(id);
            db.UserPhotos.Remove(userPhoto);
            db.SaveChanges();
            return RedirectToAction("Index","Users");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
