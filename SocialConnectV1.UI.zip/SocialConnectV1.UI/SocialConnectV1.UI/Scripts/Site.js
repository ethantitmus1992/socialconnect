﻿//The functions in this script are shared on every page
$(function () {

   
    var el = $('#site-wrapper'),
        lastY = el.scrollTop();
   el.on('scroll', function () {
        var leftNav = $('.left-nav');
        var rightNav = $('.right-nav');
        var panel = $('.trending-panel');
        var widthL = leftNav.width();
        var widthR = rightNav.width();
        var rightCol_width = $('.right-nav').width() + 10;
        var panel_width = $('#mid-col').outerWidth() * 0.4;
       


        var currY = el.scrollTop(),
            y = (currY > lastY) ? 'down' : ((currY === lastY) ? 'none' : 'up');
        console.log(y);
        if (y == 'down') {
            $('.search-bar,.mbl-nav-btns,.mbl-side-menu').addClass('moveUp');
        } else {
            $('.search-bar,.mbl-nav-btns,.mbl-side-menu').removeClass('moveUp');
        }
        lastY = currY;
        

        if ($(this).scrollTop() > 44) {
            leftNav.addClass('sticky');
            rightNav.addClass('sticky');
            leftNav.css({ "width": widthL + "px" });
            rightNav.css({ "width": widthR + "px" });
            
        } else {
            leftNav.removeClass('sticky');
            rightNav.removeClass('sticky');
            leftNav.css({ "width": "100%" });
            rightNav.css({ "width": "100%" });
            
        }

        if ($(this).scrollTop() > 100) {
            panel.addClass('sticky');
            panel.css({ "right": rightCol_width + 'px', "width": panel_width + 'px' });
        } else {
            panel.css({ "right": 0 });
            panel.removeClass('sticky');
        }

        
    });

  

 
      
 

    $('#loadMsgCount,#loadMsgCount2').load('/Messages/MsgCount');
    $('#loadContactForm').load('/Support/Contact');
    $('#loadNotifications').load('/Notifications/Notifications');
    

    $('#notify-btn').load('/Notifications/NotifyCount');
    $('#notify-btn2').load('/Notifications/NotifyCount');
   

    $('.back-to-top').click(function () {
        $('#site-wrapper').animate({ scrollTop: 0 }, 'slow');
    });


    $('.post-img-container img').click(function () {
        var src = $(this).attr('src');
        $('.modalimg-content').attr("src", src);
        $('.modalimg').fadeIn('slow');
    });

    $('.message-img img').click(function () {
        var src = $(this).attr('src');
        $('.modalimg-content').attr("src", src);
        $('.modalimg').fadeIn('slow');
    });

    $('.modalimg .closeModal').click(function () {
        $('.modalimg').fadeOut('slow');
    });
    

  

    $('#offlineMenu').popover({
        title: 'Sorry!',
        content: 'You must be logged in to use these tools.',
        placement: 'bottom',
        trigger: 'hover'
    });

  

    $('.adminBtn').click(function () {
        var arrow = $(this).children('i:last');
        arrow.toggleClass('fa-angle-double-up');
        if (arrow.hasClass('fa-angle-double-up')) {
            arrow.removeClass('fa-angle-double-down');
        } else {
            arrow.addClass('fa-angle-double-down');
        }
    });


    $('.backBtn').click(function () {
        history.go(-1);
    });


    //Website search config
    $('#search-btn').click(function () {
        $('#mid-col').html('<div id="search1"></div><div id="search2"></div>');
        var txt1 = $('#search-box').val();
        var txt2 = txt1;
        var sa1 = $('#search1');
        var sa2 = $('#search2');
        var loader = $('#loading');

        if (txt1 != '') {
            loader.fadeIn();
            setTimeout(function () {
                $.ajax({
                    url: '/Users/UserSearch?q=' + txt1, success: function (data) {
                        sa1.html(data);
                    }
                });

                $.ajax({
                    url: '/Posts/PostSearch?q=' + txt2, success: function (data) {
                        sa2.html(data);
                    }
                });

                $('#search-box').val('');
                loader.fadeOut('slow');
            }, 1800);
        } else {
            alert('Please enter a search term!');
        }

    });

    $('#search-box').keypress(function (e) {
        if (e.which == 13) {
            $('#search-btn').trigger('click');
        }
    });





    //Mobile side menu config
    $('.mbl-menu-btn').click(function () {
        $('.mbl-side-menu').toggleClass('open');
    });


   
  

  


});