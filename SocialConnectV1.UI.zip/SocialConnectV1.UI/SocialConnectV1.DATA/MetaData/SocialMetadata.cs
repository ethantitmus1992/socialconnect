﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SocialConnectV1.DATA
{
   

    public class UserMetadata
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }
        public string AspId { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd MMM yyy - hh:mm tt}")]
        public System.DateTime SignUpDate { get; set; }
        public string ProfilePhoto { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CommentLike> CommentLikes { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CommentReply> CommentReplies { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Comment> Comments { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Friend> Friends { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Friend> Friends1 { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Message> Messages { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Message> Messages1 { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Poke> Pokes { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<PostLike> PostLikes { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Post> Posts { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Profile> Profiles { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Respons> Responses { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<UserPhoto> UserPhotos { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Notification> Notifications { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Notification> Notifications1 { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Bookmark> Bookmarks { get; set; }
    }

    [MetadataType(typeof(UserMetadata))]
    public partial class User
    {
        [Display(Name = "Name")]
        public string FullName
        {
            get
            {
                return FirstName + " " + LastName;
            }
        }
    }



    public class PostMetadata
    {
        public System.Guid PostId { get; set; }
        public int UserId { get; set; }
        [UIHint("MultilineText")]
        public string PostContent { get; set; }
        public int PostBackgroundId { get; set; }
        public string PostImage { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd MMM yyy - hh:mm tt}")]
        public System.DateTime PostDate { get; set; }
        public bool IsRemoved { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Comment> Comments { get; set; }
        public virtual PostBackground PostBackground { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<PostLike> PostLikes { get; set; }
        public virtual User User { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Bookmark> Bookmarks { get; set; }
    }


    [MetadataType(typeof(PostMetadata))]
    public partial class Post { }


    public class ProfileMetadata
    {
        public System.Guid ProfileId { get; set; }
        public int UserId { get; set; }
        public string FullName { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd MMM yyy}")]
        public System.DateTime DOB { get; set; }
        [UIHint("MultilineText")]
        [DisplayFormat(NullDisplayText = "[ UNAVAILABLE ]")]
        public string About { get; set; }
        [UIHint("MultilineText")]
        [DisplayFormat(NullDisplayText = "[ UNAVAILABLE ]")]
        public string PlacesWorked { get; set; }
        [UIHint("MultilineText")]
        [DisplayFormat(NullDisplayText = "[ UNAVAILABLE ]")]
        public string Education { get; set; }
        [UIHint("MultilineText")]
        [DisplayFormat(NullDisplayText = "[ UNAVAILABLE ]")]
        public string Hobbies { get; set; }
        [UIHint("MultilineText")]
        [DisplayFormat(NullDisplayText = "[ UNAVAILABLE ]")]
        public string Music { get; set; }
        [UIHint("MultilineText")]
        [DisplayFormat(NullDisplayText = "[ UNAVAILABLE ]")]
        public string TV { get; set; }
        public string City { get; set; }
        public int StateId { get; set; }
        public bool IsPublic { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Poke> Pokes { get; set; }
        public virtual State State { get; set; }
        public virtual User User { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<UserPhoto> UserPhotos { get; set; }
    }

    [MetadataType(typeof(ProfileMetadata))]
    public partial class Profile { }



    public class MessageMetadata
    {
        public int MessageId { get; set; }
        public int FromUserId { get; set; }
        public Nullable<int> ToUserId { get; set; }
        [DisplayFormat(NullDisplayText = "(no subject)")]
        public string Subject { get; set; }
        [UIHint("MultilineText")]
        public string Body { get; set; }
        public string Image { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd MMM yyy - hh:mm tt}")]
        public System.DateTime DateSent { get; set; }
        public bool IsRead { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd MMM yyy - hh:mm tt}")]
        public Nullable<System.DateTime> ViewedDate { get; set; }

        public virtual User User { get; set; }
        public virtual User User1 { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Respons> Responses { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Notification> Notifications { get; set; }
    }

    [MetadataType(typeof(MessageMetadata))]
    public partial class Message { }



    public class ResponsMetadata
    {
        public int ResponseId { get; set; }
        public int MessageId { get; set; }
        public int FromUserId { get; set; }
        [UIHint("MultilineText")]
        public string ReplyContent { get; set; }
        public string Image { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd MMM yyy - hh:mm tt}")]
        public System.DateTime DateSent { get; set; }

        public virtual Message Message { get; set; }
        public virtual User User { get; set; }
    }


    [MetadataType(typeof(ResponsMetadata))]
    public partial class Respons { }


    public class UserPhotoMetadata
    {
        public System.Guid UserPhotoId { get; set; }
        public string Image { get; set; }
        [UIHint("MultilineText")]
        public string Caption { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd MMM yyy - hh:mm tt}")]
        public System.DateTime DateAdded { get; set; }
        public int UserId { get; set; }
        public System.Guid ProfileId { get; set; }
        public bool IsProfileImage { get; set; }
        public bool IsPublic { get; set; }

        public virtual Profile Profile { get; set; }
        public virtual User User { get; set; }
    }


    [MetadataType(typeof(UserPhotoMetadata))]
    public partial class UserPhoto { }



    public class NotificationMetadata
    {
        public int NotificationId { get; set; }
        public int CurrentUserId { get; set; }
        public int NotifyUserId { get; set; }
        public int TypeId { get; set; }
        public string NotifyContent { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd MMM yyy - hh:mm tt}")]
        public System.DateTime NotifyDate { get; set; }
        public bool IsViewed { get; set; }
        public Nullable<System.Guid> PostId { get; set; }
        public Nullable<int> MessageId { get; set; }

        public virtual Type Type { get; set; }
        public virtual User User { get; set; }
        public virtual User User1 { get; set; }
        public virtual Message Message { get; set; }
        public virtual Post Post { get; set; }
    }

    [MetadataType(typeof(NotificationMetadata))]
    public partial class Notification { }


}//end namespace
